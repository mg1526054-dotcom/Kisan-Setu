const cropSelect = document.getElementById("crop-select");
const marketSelect = document.getElementById("market-select");
const dateInput = document.getElementById("date-select");
const forecastBtn = document.getElementById("forecast-btn");
const resultSection = document.getElementById("result-section");
const emptyState = document.getElementById("empty-state");
const errorState = document.getElementById("error-state");

let priceChart = null;

function defaultTargetDate() {
  const d = new Date();
  d.setDate(d.getDate() + 7);
  return d.toISOString().slice(0, 10);
}
dateInput.value = defaultTargetDate();

async function fetchJSON(url, options) {
  const res = await fetch(url, options);
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail || `Request failed: ${res.status}`);
  }
  return res.json();
}

async function loadCrops() {
  const crops = await fetchJSON("/api/crops");
  cropSelect.innerHTML = crops.map(c => `<option value="${c.id}">${c.name}</option>`).join("");
  if (crops.length) await loadMarkets(crops[0].name);
}

async function loadMarkets(cropName) {
  const markets = await fetchJSON(`/api/markets?crop=${encodeURIComponent(cropName)}`);
  marketSelect.innerHTML = markets.map(m => `<option value="${m.id}">${m.name} (${m.district})</option>`).join("");
}

cropSelect.addEventListener("change", async () => {
  const selectedName = cropSelect.options[cropSelect.selectedIndex].text;
  await loadMarkets(selectedName);
});

function showError(message) {
  errorState.textContent = message;
  errorState.classList.remove("hidden");
  resultSection.classList.add("hidden");
  emptyState.classList.add("hidden");
}

function renderDrivers(drivers) {
  const list = document.getElementById("drivers-list");
  list.innerHTML = drivers.map(d => `
    <li>
      <span class="driver-dot ${d.direction === 'upward' ? 'up' : 'down'}"></span>
      <span>${d.sentence}</span>
    </li>
  `).join("");
}

function renderMetrics(metrics) {
  const grid = document.getElementById("metrics-grid");
  const items = [
    { label: "Model MAE", value: `₹${metrics.model_mae}` },
    { label: "Model MAPE", value: `${metrics.model_mape_pct}%` },
    { label: "Range coverage", value: `${metrics.range_coverage_pct}%` },
    { label: "Baseline MAE", value: `₹${metrics.baseline_mae}` },
    { label: "Baseline MAPE", value: `${metrics.baseline_mape_pct}%` },
    { label: "Test samples", value: metrics.n_test },
  ];
  grid.innerHTML = items.map(i => `
    <div class="metric-box">
      <div class="value">${i.value}</div>
      <div class="label">${i.label}</div>
    </div>
  `).join("");
}

async function renderChart(cropId, marketId) {
  const history = await fetchJSON(`/api/history?crop_id=${cropId}&market_id=${marketId}`);
  const recent = history.slice(-52); // last ~1 year of weekly data
  const labels = recent.map(h => h.date);
  const modal = recent.map(h => h.modal_price);
  const min = recent.map(h => h.min_price);
  const max = recent.map(h => h.max_price);

  const ctx = document.getElementById("price-chart").getContext("2d");
  if (priceChart) priceChart.destroy();
  priceChart = new Chart(ctx, {
    type: "line",
    data: {
      labels,
      datasets: [
        { label: "Modal price", data: modal, borderColor: "#2C5F2D", backgroundColor: "rgba(44,95,45,0.08)", fill: true, tension: 0.25, pointRadius: 0, borderWidth: 2 },
        { label: "Daily high", data: max, borderColor: "#E29930", borderDash: [4, 3], pointRadius: 0, borderWidth: 1 },
        { label: "Daily low", data: min, borderColor: "#97BC62", borderDash: [4, 3], pointRadius: 0, borderWidth: 1 },
      ],
    },
    options: {
      responsive: true,
      plugins: { legend: { position: "bottom", labels: { boxWidth: 10, font: { size: 11 } } } },
      scales: {
        x: { ticks: { maxTicksLimit: 8, font: { size: 10 } } },
        y: { ticks: { callback: v => `₹${v}` } },
      },
    },
  });
}

async function getForecast() {
  errorState.classList.add("hidden");
  emptyState.classList.add("hidden");
  forecastBtn.disabled = true;
  forecastBtn.textContent = "Forecasting…";

  try {
    const cropId = parseInt(cropSelect.value, 10);
    const marketId = parseInt(marketSelect.value, 10);
    const targetDate = dateInput.value;

    const forecast = await fetchJSON("/api/forecast", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ crop_id: cropId, market_id: marketId, target_date: targetDate }),
    });

    document.getElementById("risk-tag").textContent = `Risk: ${forecast.risk_level}`;
    document.getElementById("confidence-text").textContent = `Confidence ${Math.round(forecast.confidence * 100)}%`;
    document.getElementById("forecast-label").textContent =
      `Predicted price for ${forecast.crop} at ${forecast.market}, week of ${forecast.target_date}`;
    document.getElementById("forecast-range").innerHTML =
      `₹${Math.round(forecast.predicted_min)} – ₹${Math.round(forecast.predicted_max)}<span class="unit">/quintal</span>`;
    document.getElementById("advisory-text").textContent = forecast.advisory;
    document.getElementById("disclaimer-text").textContent = forecast.disclaimer;

    renderDrivers(forecast.drivers);
    renderMetrics(forecast.model_metrics);
    await renderChart(cropId, marketId);

    resultSection.classList.remove("hidden");
  } catch (err) {
    showError(err.message || "Something went wrong while generating the forecast.");
  } finally {
    forecastBtn.disabled = false;
    forecastBtn.textContent = "Get forecast";
  }
}

forecastBtn.addEventListener("click", getForecast);

loadCrops().catch(err => showError(err.message));
